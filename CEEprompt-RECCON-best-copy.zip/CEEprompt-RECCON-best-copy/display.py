import pickle

file = open('outputs/robertaMLM-dailydialog-cls-with-context-fold1/test_predictions.pkl','rb')
data = pickle.load(file)

# for item in data:
#     for sub_item in item:
#         print(sub_item)
#     print('\n')
# print('len(data)', len(data))

for item in data:
    print(item)
print('\n')
print('len(data)', len(data))